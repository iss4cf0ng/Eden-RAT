import socket
import re
import os
import ssl

# Set the server IP address and port
# TODO Start
HOST, PORT = '127.0.0.1', 9999
# TODO end

# Create a server socket, bind it to the specified IP and port, and start listening
# TODO Start
serverSocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
serverSocket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
serverSocket.bind((HOST, PORT))
serverSocket.listen(10)
# TODO end

while True:
    print('Ready to serve...')
    # Accept an incoming connection and get the client's address
    # TODO Start
    client_socket, client_address = serverSocket.accept()
    # TODO end

    print('Received a connection from:', client_address)

    try:
        # Receive and parse the client's request
        # TODO Start
        request = client_socket.recv(65536).decode('utf-8')
        # TODO end

        # Extract the requested filename from the HTTP request
        if request == "":
            request = "/ /"
        filename = request.split()[1].partition("/")[2]
        print(filename)
        file_path = "/" + filename
        print(file_path)
        
        if file_path.startswith('//'):
            file_path = file_path[2:]
        elif file_path.startswith('/'):
            file_path = file_path[1:]

        print('->' + file_path)

        # Check if the requested file is available in the cache
        file_exist = "false"
        try:
            if '?' in file_path or file_path.endswith('/'):
                raise FileNotFoundError

            content = b''
            with open(file_path, 'rb') as cache_file:
                while True:
                    buff = cache_file.read(65536)
                    if not buff:
                        break

                    content += buff

            file_exist = "true"

            # ProxyServer finds a cache hit and generates a response message
            # Send the file data to the client
            # TODO Start
            client_socket.sendall(content)
            # TODO End
            print('Read from cache')

        # If the file is not found in the cache, forward the request to the web server
        except FileNotFoundError:
            if file_exist == "false":
                # # Establish a connection to the web server
                # TODO Start
                srvSock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                # TODO End

                try:
                    print("Trying to connect to the web server")
                    # Connect the socket to the web server port
                    # TODO Start
                    mat = re.search(r'(?i)^Host:\s*([^\s]+)', request, re.MULTILINE)
                    host = mat.group(1)

                    domain, port = host, 80
                    if ':' in host:
                        port = int(host.split(':')[1])
                        domain = host.split(':')[0]
                        
                    srvSock.connect((domain, port))

                    # TODO End
                    print("Connected successfully")

                    # Send HTTP GET request to the web server
                    # TODO Start
                    print(request)
                    srvSock.sendall(request.encode('utf-8'))
                    # TODO End
                    print("Sent the request to the web server successfully")

                    # Receive response from the web server    
                    # If the response indicates a 404 error, return an error to the client without caching
                    # TODO Start
                    resp = srvSock.recv(65536)
                    if b'HTTP/1.1 404 Not Found\r\n' in resp:
                        client_socket.sendall(b'404 NOT FOUND.')
                        continue

                    # TODO End                    

                    # If not, cache only valid files and send the valid response to the client socket
                    # TODO Start

                    if '?' not in file_path and '.' in file_path.split('/')[-1]:
                        save_path = file_path
                        dir_name = os.path.dirname(save_path)
                        if not os.path.exists(dir_name):
                            os.makedirs(dir_name)

                        with open(save_path, 'wb') as f:
                            f.write(resp.split(b'\r\n\r\n')[1])

                    client_socket.sendall(resp)
                    # TODO End

                except Exception as ex:
                    # Handle errors related to connection issues or invalid requests
                    print("Illegal request")
                finally:
                    # Ensure the connection to the web server is closed properly
                    # TODO Start
                    srvSock.close()
                    # TODO End
    finally:
        # Close the client socket
        client_socket.close()